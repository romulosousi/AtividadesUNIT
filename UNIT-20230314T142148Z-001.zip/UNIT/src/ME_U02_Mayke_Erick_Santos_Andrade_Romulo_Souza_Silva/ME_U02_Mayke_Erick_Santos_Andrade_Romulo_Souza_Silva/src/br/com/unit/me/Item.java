package br.com.unit.me;

public interface Item {

	public void displayItem();
}
