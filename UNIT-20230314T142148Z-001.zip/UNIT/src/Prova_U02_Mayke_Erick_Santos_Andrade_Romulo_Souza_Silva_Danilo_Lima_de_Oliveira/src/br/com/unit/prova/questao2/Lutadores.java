package br.com.unit.prova.questao2;

public interface Lutadores {

	public abstract void apresentar();

	public void status();

	public void ganharLuta();

	public void perderLuta();

	public void empatarLuta();

}
