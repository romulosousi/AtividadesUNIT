package br.com.unit.prova.questao1;

public interface Comissao {
	
	public static final double TAXA_COMISSAO = 0.1;
	
	public void setVendas(double Vendas);
}
