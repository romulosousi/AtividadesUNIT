package Ex03;

public class PessoaJuridica extends Pessoa {
    String cnppj;

    public String getCnppj() {
        return cnppj;
    }

    public void setCnppj(String cnppj) {
        this.cnppj = cnppj;
    }
    
}
