package Ex03;

public class TrataException extends Exception {

    public TrataException() {
        System.out.println("Número negativo ou acima do limite!");
    }

  

    
}
